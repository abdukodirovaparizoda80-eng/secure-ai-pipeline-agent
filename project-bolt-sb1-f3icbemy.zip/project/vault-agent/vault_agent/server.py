import json
import logging
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from vault_agent.config import Settings
from vault_agent.llm import LLMError
from vault_agent.pipeline import Pipeline, PipelineError
from vault_agent.vault import VaultError

WEB_DIR = Path(__file__).resolve().parent.parent / "web"
ASSETS = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/styles.css": ("styles.css", "text/css; charset=utf-8"),
    "/app.js": ("app.js", "application/javascript; charset=utf-8"),
}
MAX_BODY_BYTES = 64 * 1024
CONTENT_SECURITY_POLICY = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
)
log = logging.getLogger("vault_agent")


def create_server(settings: Settings) -> ThreadingHTTPServer:
    pipeline = Pipeline(settings)
    allowed_hosts = {f"127.0.0.1:{settings.port}", f"localhost:{settings.port}"}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            if not self._allowed_host():
                return
            path = self.path.split("?", 1)[0]
            if path == "/api/status":
                self._json(200, {
                    "providers": {
                        "openai": bool(settings.openai_api_key),
                        "gemini": bool(settings.gemini_api_key),
                    },
                    "vault_exists": settings.vault_path.exists(),
                })
                return
            asset = ASSETS.get(path)
            if asset is None:
                self._json(404, {"error": "Not found."})
                return
            filename, content_type = asset
            self._send(200, (WEB_DIR / filename).read_bytes(), content_type)

        def do_POST(self) -> None:
            if not self._allowed_host():
                return
            try:
                body = self._read_json()
                if self.path == "/api/send":
                    result = pipeline.send(
                        master_key=_field(body, "master_key"),
                        message=_field(body, "message"),
                        provider=_field(body, "provider"),
                    )
                elif self.path == "/api/history":
                    result = {"entries": pipeline.history(_field(body, "master_key"))}
                else:
                    self._json(404, {"error": "Not found."})
                    return
            except PipelineError as exc:
                self._json(400, {"error": str(exc)})
                return
            except VaultError as exc:
                self._json(401, {"error": str(exc)})
                return
            except LLMError as exc:
                self._json(502, {"error": str(exc)})
                return
            except Exception:
                log.exception("Unhandled error while handling %s", self.path)
                self._json(500, {"error": "Something went wrong inside the local server."})
                return
            self._json(200, result)

        def _allowed_host(self) -> bool:
            if self.headers.get("Host") in allowed_hosts:
                return True
            self._json(403, {"error": "Requests must come from localhost."})
            return False

        def _read_json(self) -> dict:
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError as exc:
                raise PipelineError("Invalid request.") from exc
            if not 0 < length <= MAX_BODY_BYTES:
                raise PipelineError("Invalid request size.")
            try:
                body = json.loads(self.rfile.read(length))
            except ValueError as exc:
                raise PipelineError("Invalid request.") from exc
            if not isinstance(body, dict):
                raise PipelineError("Invalid request.")
            return body

        def _json(self, status: int, payload: dict) -> None:
            self._send(status, json.dumps(payload).encode("utf-8"), "application/json; charset=utf-8")

        def _send(self, status: int, body: bytes, content_type: str) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", CONTENT_SECURITY_POLICY)
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(("127.0.0.1", settings.port), Handler)
    server.daemon_threads = True
    return server


def _field(body: dict, name: str) -> str:
    value = body.get(name)
    if not isinstance(value, str):
        raise PipelineError(f"Missing {name.replace('_', ' ')}.")
    return value
