const state = { provider: null, stepTimer: null };

const el = {
  message: document.getElementById("message"),
  masterKey: document.getElementById("master-key"),
  toggleKey: document.getElementById("toggle-key"),
  keyHint: document.getElementById("key-hint"),
  send: document.getElementById("send"),
  error: document.getElementById("form-error"),
  providerButtons: [...document.querySelectorAll("#provider button")],
  steps: [...document.querySelectorAll("#pipeline li")],
  badge: document.getElementById("redaction-badge"),
  replyEmpty: document.getElementById("reply-empty"),
  replyBody: document.getElementById("reply-body"),
  sentDetails: document.getElementById("sent-details"),
  sentBody: document.getElementById("sent-body"),
  historyLoad: document.getElementById("load-history"),
  historyList: document.getElementById("history-list"),
};

const PROVIDER_LABELS = { openai: "OpenAI", gemini: "Gemini" };

async function api(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

function showError(message) {
  el.error.textContent = message;
}

function selectProvider(name) {
  state.provider = name;
  el.providerButtons.forEach((button) => {
    const active = button.dataset.provider === name;
    button.setAttribute("aria-checked", String(active));
    button.classList.toggle("is-active", active);
  });
}

function setSteps(activeIndex) {
  el.steps.forEach((step, index) => {
    step.classList.toggle("done", activeIndex > index);
    step.classList.toggle("active", activeIndex === index);
  });
}

function clearStepTimer() {
  clearTimeout(state.stepTimer);
  state.stepTimer = null;
}

function startPipeline() {
  clearStepTimer();
  setSteps(0);
  state.stepTimer = setTimeout(() => setSteps(1), 500);
}

function finishPipeline() {
  clearStepTimer();
  setSteps(4);
}

function resetPipeline() {
  clearStepTimer();
  setSteps(-1);
}

function setBusy(busy) {
  el.send.disabled = busy;
  el.send.textContent = busy ? "Working..." : "Encrypt and send";
}

async function sendMessage() {
  const message = el.message.value.trim();
  const masterKey = el.masterKey.value;
  showError("");
  if (!message) return showError("Write a message before sending.");
  if (!masterKey) return showError("Enter your master key to encrypt this message.");
  if (!state.provider) return showError("No AI provider is configured yet. Add an API key and restart.");

  setBusy(true);
  startPipeline();
  try {
    const data = await api("/api/send", { message, master_key: masterKey, provider: state.provider });
    finishPipeline();
    renderReply(data);
  } catch (error) {
    resetPipeline();
    showError(error.message);
  } finally {
    setBusy(false);
  }
}

function renderReply(data) {
  el.replyEmpty.hidden = true;
  el.replyBody.hidden = false;
  el.replyBody.textContent = data.reply;
  el.replyBody.classList.remove("fade-in");
  void el.replyBody.offsetWidth;
  el.replyBody.classList.add("fade-in");
  el.sentBody.textContent = data.sent;
  el.sentDetails.hidden = false;
  el.sentDetails.open = false;
  const count = data.redactions;
  el.badge.textContent =
    count === 0 ? "Nothing needed protecting" : `${count} private ${count === 1 ? "value" : "values"} protected`;
  el.badge.classList.add("success");
}

async function loadHistory() {
  const masterKey = el.masterKey.value;
  showError("");
  if (!masterKey) return showError("Enter your master key to unlock your history.");

  el.historyLoad.disabled = true;
  try {
    const data = await api("/api/history", { master_key: masterKey });
    renderHistory(data.entries);
  } catch (error) {
    showError(error.message);
  } finally {
    el.historyLoad.disabled = false;
  }
}

function renderHistory(entries) {
  el.historyList.replaceChildren();
  if (entries.length === 0) {
    const empty = document.createElement("li");
    empty.className = "history-empty";
    empty.textContent = "No saved conversations yet.";
    el.historyList.append(empty);
    return;
  }
  entries.forEach((entry) => el.historyList.append(historyItem(entry)));
}

function historyItem(entry) {
  const item = document.createElement("li");
  item.className = "history-item";

  const details = document.createElement("details");
  const summary = document.createElement("summary");
  const title = document.createElement("span");
  title.className = "history-title";
  title.textContent = truncate(entry.prompt, 90);
  const meta = document.createElement("span");
  meta.className = "history-meta";
  meta.textContent = `${PROVIDER_LABELS[entry.provider] ?? entry.provider} · ${formatDate(entry.created_at)} · ${entry.redactions} protected`;
  summary.append(title, meta);

  const body = document.createElement("div");
  body.className = "history-body";
  body.append(
    labelled("You wrote", entry.prompt),
    labelled("Reply", entry.reply),
  );

  details.append(summary, body);
  item.append(details);
  return item;
}

function labelled(label, text) {
  const wrapper = document.createElement("div");
  const heading = document.createElement("p");
  heading.className = "history-label";
  heading.textContent = label;
  const content = document.createElement("p");
  content.className = "history-text";
  content.textContent = text;
  wrapper.append(heading, content);
  return wrapper;
}

function truncate(text, max) {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function formatDate(iso) {
  return new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

async function init() {
  try {
    const response = await fetch("/api/status");
    const status = await response.json();
    el.providerButtons.forEach((button) => {
      const configured = Boolean(status.providers[button.dataset.provider]);
      button.disabled = !configured;
      button.title = configured ? "" : "Not configured yet";
    });
    const first = el.providerButtons.find((button) => !button.disabled);
    if (first) selectProvider(first.dataset.provider);
    if (!status.vault_exists) {
      el.keyHint.textContent = "First use: this master key will create your local vault. Keep it safe, it cannot be recovered.";
    }
  } catch {
    showError("The local server is not responding. Restart Vault Agent.");
  }
}

el.providerButtons.forEach((button) => {
  button.addEventListener("click", () => selectProvider(button.dataset.provider));
});

el.toggleKey.addEventListener("click", () => {
  const reveal = el.masterKey.type === "password";
  el.masterKey.type = reveal ? "text" : "password";
  el.toggleKey.textContent = reveal ? "Hide" : "Show";
});

el.send.addEventListener("click", sendMessage);
el.historyLoad.addEventListener("click", loadHistory);
el.message.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key === "Enter") sendMessage();
});

init();
