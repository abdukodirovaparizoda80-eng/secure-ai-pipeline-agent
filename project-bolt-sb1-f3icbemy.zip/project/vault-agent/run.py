"""Starts Vault Agent on the loopback interface and opens it in the browser."""

import sys
import webbrowser


def main() -> int:
    try:
        import cryptography  # noqa: F401
    except ImportError:
        print("Missing dependency. Run: pip install -r requirements.txt")
        return 1

    from vault_agent.config import load_settings
    from vault_agent.server import create_server

    settings = load_settings()
    server = create_server(settings)
    url = f"http://127.0.0.1:{settings.port}/"
    print(f"Vault Agent is running at {url}")
    print("Press Ctrl+C to stop.")
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
