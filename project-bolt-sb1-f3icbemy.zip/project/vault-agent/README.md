# Vault Agent

A local, privacy-first AI pipeline. You type a message and a master key in a browser page served from your own machine. Sensitive values are replaced before anything is sent to OpenAI or Gemini, and the reply is rebuilt locally.

## How it protects your data

1. **Master key never stored.** It is stretched with scrypt and used to rebuild a data key. Only the key derivation result lives in memory during a request.
2. **Shamir's Secret Sharing (2 of 2).** The data key is split into two shares. One share sits in `data/vault.json`; the other is derived from your master key. Neither share alone reveals the data key.
3. **Encrypted at rest.** The conversation history in `data/history.enc` is sealed with AES-256-GCM under the data key.
4. **Redaction before sending.** Emails, phone numbers, card numbers, SSNs, IP addresses and API keys are detected automatically. Anything you wrap in double braces, such as `{{ account 4411 }}`, is also replaced. The provider only receives placeholders such as `[[EMAIL_1]]`. The app shows you exactly what was sent.
5. **Loopback only.** The server binds to `127.0.0.1` and rejects requests whose Host header is not localhost.

Note: a language model cannot reason over ciphertext, so the provider always receives the redacted text. Privacy comes from ensuring that the sensitive values themselves never leave your machine.

## Setup

Requires Python 3.10 or newer.

```bash
./setup.sh          # macOS / Linux
./start.sh
```

Windows:

```bat
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
copy .env.example .env
.venv\Scripts\python run.py
```

Then add your API key(s) to `.env`. The app opens at http://127.0.0.1:8765.

## Files

- `run.py` starts the server and opens the browser.
- `vault_agent/sharing.py` Shamir's Secret Sharing over GF(256).
- `vault_agent/vault.py` key derivation, vault creation and encrypted history.
- `vault_agent/redaction.py` detection, placeholder substitution and restoration.
- `vault_agent/llm.py` OpenAI and Gemini calls.
- `vault_agent/pipeline.py` the end-to-end pipeline.
- `vault_agent/server.py` the local HTTP server.
- `web/` the interface.

## Important

If you lose your master key, the vault cannot be opened. There is no recovery path by design.
