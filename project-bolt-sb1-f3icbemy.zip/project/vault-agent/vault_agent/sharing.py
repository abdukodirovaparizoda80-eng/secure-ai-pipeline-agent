"""Shamir's Secret Sharing over GF(256), applied byte by byte.

A threshold-2 polynomial f(x) = secret + a*x hides the secret in f(0). Any two
points recover it, while a single point reveals nothing about it.
"""


def _mul(a: int, b: int) -> int:
    result = 0
    while b:
        if b & 1:
            result ^= a
        a <<= 1
        if a & 0x100:
            a ^= 0x11B
        b >>= 1
    return result


def _inv(a: int) -> int:
    if a == 0:
        raise ZeroDivisionError("zero has no inverse in GF(256)")
    result = 1
    for _ in range(254):
        result = _mul(result, a)
    return result


def companion_share(secret: bytes, known: tuple[int, bytes], new_x: int) -> bytes:
    """Return the share at new_x for the line through (0, secret) and a known share."""
    known_x, known_y = known
    inv_known_x = _inv(known_x)
    slopes = [_mul(y ^ s, inv_known_x) for y, s in zip(known_y, secret)]
    return bytes(s ^ _mul(a, new_x) for s, a in zip(secret, slopes))


def recover(shares: list[tuple[int, bytes]]) -> bytes:
    xs = [x for x, _ in shares]
    if len(shares) < 2 or len(set(xs)) != len(xs):
        raise ValueError("At least two distinct shares are required.")
    length = len(shares[0][1])
    out = bytearray(length)
    for i, (x_i, y_i) in enumerate(shares):
        numerator = 1
        denominator = 1
        for j, (x_j, _) in enumerate(shares):
            if i == j:
                continue
            numerator = _mul(numerator, x_j)
            denominator = _mul(denominator, x_j ^ x_i)
        coefficient = _mul(numerator, _inv(denominator))
        for position in range(length):
            out[position] ^= _mul(y_i[position], coefficient)
    return bytes(out)
