"""Replaces private values with opaque placeholders before anything leaves the machine."""

import re

TOKEN_PATTERN = re.compile(r"\[\[[A-Z_]+_\d+\]\]")
_MARKED = re.compile(r"\{\{(.+?)\}\}", re.DOTALL)
_DETECTORS = [
    ("API_KEY", re.compile(r"\b(?:sk-[A-Za-z0-9_-]{16,}|AIza[0-9A-Za-z_-]{30,}|gh[pousr]_[A-Za-z0-9]{30,})")),
    ("EMAIL", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),
    ("CARD", re.compile(r"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("IP", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
    ("PHONE", re.compile(r"(?<![\w+])\+?\d(?:[ .()-]?\d){8,14}(?!\w)")),
]


def redact(text: str) -> tuple[str, dict[str, str]]:
    """Return the redacted text and a token-to-original mapping."""
    candidates = []
    for match in _MARKED.finditer(text):
        candidates.append((0, match.start(), match.end(), "SECRET", match.group(1).strip()))
    for priority, (label, pattern) in enumerate(_DETECTORS, start=1):
        for match in pattern.finditer(text):
            candidates.append((priority, match.start(), match.end(), label, match.group(0)))

    accepted: list[tuple[int, int, str, str]] = []
    for _, start, end, label, value in sorted(candidates, key=lambda c: (c[0], c[1])):
        if not value:
            continue
        if any(start < a_end and a_start < end for a_start, a_end, _, _ in accepted):
            continue
        accepted.append((start, end, label, value))
    accepted.sort()

    parts: list[str] = []
    mapping: dict[str, str] = {}
    tokens_by_value: dict[tuple[str, str], str] = {}
    counters: dict[str, int] = {}
    cursor = 0
    for start, end, label, value in accepted:
        token = tokens_by_value.get((label, value))
        if token is None:
            counters[label] = counters.get(label, 0) + 1
            token = f"[[{label}_{counters[label]}]]"
            tokens_by_value[(label, value)] = token
            mapping[token] = value
        parts.append(text[cursor:start])
        parts.append(token)
        cursor = end
    parts.append(text[cursor:])
    return "".join(parts), mapping


def restore(text: str, mapping: dict[str, str]) -> str:
    return TOKEN_PATTERN.sub(lambda match: mapping.get(match.group(0), match.group(0)), text)
