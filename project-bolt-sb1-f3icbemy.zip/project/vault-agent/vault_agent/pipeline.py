import threading
import uuid
from datetime import datetime, timezone

from vault_agent import llm, vault
from vault_agent.config import Settings
from vault_agent.redaction import redact, restore

PROVIDERS = ("openai", "gemini")
MAX_MESSAGE_CHARS = 20_000


class PipelineError(Exception):
    pass


class Pipeline:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._history_lock = threading.Lock()

    def send(self, master_key: str, message: str, provider: str) -> dict:
        message = message.strip()
        if not message:
            raise PipelineError("Write a message before sending.")
        if len(message) > MAX_MESSAGE_CHARS:
            raise PipelineError("Message is too long (20,000 characters maximum).")
        if provider not in PROVIDERS:
            raise PipelineError("Choose OpenAI or Gemini.")

        data_key = vault.open_vault(self._settings, master_key)
        redacted, mapping = redact(message)
        raw_reply = llm.complete(self._settings, provider, redacted)
        reply = restore(raw_reply, mapping)

        entry = {
            "id": str(uuid.uuid4()),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "provider": provider,
            "prompt": message,
            "sent": redacted,
            "reply": reply,
            "redactions": len(mapping),
        }
        with self._history_lock:
            entries = vault.load_history(self._settings, data_key)
            entries.append(entry)
            vault.save_history(self._settings, data_key, entries)

        return {
            "reply": reply,
            "sent": redacted,
            "redactions": len(mapping),
            "provider": provider,
        }

    def history(self, master_key: str) -> list[dict]:
        data_key = vault.open_vault(self._settings, master_key)
        with self._history_lock:
            entries = vault.load_history(self._settings, data_key)
        return list(reversed(entries))
