#!/usr/bin/env bash
# One-time setup: creates a virtual environment, installs dependencies and a .env file.
set -euo pipefail
cd "$(dirname "$0")"

python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env. Add your OpenAI and/or Gemini API key to it."
fi

echo "Setup complete. Start the app with: ./start.sh"
