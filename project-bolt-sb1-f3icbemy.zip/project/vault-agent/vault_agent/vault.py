"""Local encrypted vault.

The master key is never written to disk. It is stretched with scrypt into a
secret that yields one Shamir share (2 of 2). The other share is stored on disk.
The 32-byte data key is only rebuilt when both shares are present, so the disk
file alone cannot decrypt anything.
"""

import base64
import hashlib
import hmac
import json
import os
from pathlib import Path

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

from vault_agent import sharing
from vault_agent.config import Settings

VERIFIER_PHRASE = b"vault-agent verified"
VERIFIER_AAD = b"verifier"
HISTORY_AAD = b"history"


class VaultError(Exception):
    pass


def open_vault(settings: Settings, master_key: str) -> bytes:
    if not master_key:
        raise VaultError("Enter your master key.")
    if not settings.vault_path.exists():
        return _create_vault(settings, master_key)

    record = json.loads(settings.vault_path.read_text(encoding="utf-8"))
    salt = _unb64(record["salt"])
    data_key = sharing.recover(
        [(1, _unb64(record["disk_share"])), (2, _master_share(master_key, salt))]
    )
    try:
        _open(data_key, record["verifier"], VERIFIER_AAD)
    except InvalidTag as exc:
        raise VaultError("That master key does not unlock this vault.") from exc
    return data_key


def load_history(settings: Settings, data_key: bytes) -> list[dict]:
    if not settings.history_path.exists():
        return []
    blob = json.loads(settings.history_path.read_text(encoding="utf-8"))
    return json.loads(_open(data_key, blob, HISTORY_AAD))


def save_history(settings: Settings, data_key: bytes, entries: list[dict]) -> None:
    blob = _seal(data_key, json.dumps(entries).encode("utf-8"), HISTORY_AAD)
    _write_json(settings.history_path, blob)


def _create_vault(settings: Settings, master_key: str) -> bytes:
    salt = os.urandom(16)
    data_key = os.urandom(32)
    disk_share = sharing.companion_share(
        data_key, (2, _master_share(master_key, salt)), 1
    )
    record = {
        "version": 1,
        "salt": _b64(salt),
        "disk_share": _b64(disk_share),
        "verifier": _seal(data_key, VERIFIER_PHRASE, VERIFIER_AAD),
    }
    _write_json(settings.vault_path, record)
    return data_key


def _master_share(master_key: str, salt: bytes) -> bytes:
    secret = Scrypt(salt=salt, length=32, n=2**15, r=8, p=1).derive(
        master_key.encode("utf-8")
    )
    return hmac.new(secret, b"vault-agent share 2", hashlib.sha256).digest()


def _seal(key: bytes, plaintext: bytes, aad: bytes) -> dict:
    nonce = os.urandom(12)
    return {"nonce": _b64(nonce), "ct": _b64(AESGCM(key).encrypt(nonce, plaintext, aad))}


def _open(key: bytes, blob: dict, aad: bytes) -> bytes:
    return AESGCM(key).decrypt(_unb64(blob["nonce"]), _unb64(blob["ct"]), aad)


def _write_json(path: Path, payload: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(payload), encoding="utf-8")
    tmp.chmod(0o600)
    os.replace(tmp, path)


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.b64decode(text)
