import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    port: int
    openai_api_key: str
    openai_model: str
    gemini_api_key: str
    gemini_model: str
    data_dir: Path

    @property
    def vault_path(self) -> Path:
        return self.data_dir / "vault.json"

    @property
    def history_path(self) -> Path:
        return self.data_dir / "history.enc"


def _load_env_file(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def load_settings() -> Settings:
    _load_env_file(ROOT / ".env")
    return Settings(
        port=int(os.environ.get("VAULT_AGENT_PORT", "8765")),
        openai_api_key=os.environ.get("OPENAI_API_KEY", "").strip(),
        openai_model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip(),
        gemini_api_key=os.environ.get("GEMINI_API_KEY", "").strip(),
        gemini_model=os.environ.get("GEMINI_MODEL", "gemini-2.0-flash").strip(),
        data_dir=ROOT / "data",
    )
