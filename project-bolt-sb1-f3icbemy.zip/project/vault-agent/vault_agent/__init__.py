"""Vault Agent: a local, privacy-first pipeline in front of OpenAI and Gemini."""
