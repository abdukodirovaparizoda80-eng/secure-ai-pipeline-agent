import json
import urllib.error
import urllib.request

from vault_agent.config import Settings

SYSTEM_PROMPT = (
    "You are a concise, careful assistant inside a privacy-preserving pipeline. "
    "Some private values were replaced with placeholders such as [[EMAIL_1]] or [[SECRET_1]]. "
    "Treat each placeholder as an opaque reference: reuse it exactly as written wherever the "
    "value belongs, and never guess, invent or expand what it stands for."
)
TIMEOUT_SECONDS = 60


class LLMError(Exception):
    pass


def complete(settings: Settings, provider: str, prompt: str) -> str:
    if provider == "openai":
        return _openai(settings, prompt)
    if provider == "gemini":
        return _gemini(settings, prompt)
    raise LLMError("Unknown provider.")


def _openai(settings: Settings, prompt: str) -> str:
    if not settings.openai_api_key:
        raise LLMError("OpenAI is not configured yet. Add its API key to the .env file and restart.")
    data = _post(
        "https://api.openai.com/v1/chat/completions",
        {"Authorization": f"Bearer {settings.openai_api_key}"},
        {
            "model": settings.openai_model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        },
    )
    try:
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise LLMError("OpenAI returned an unexpected response.") from exc


def _gemini(settings: Settings, prompt: str) -> str:
    if not settings.gemini_api_key:
        raise LLMError("Gemini is not configured yet. Add its API key to the .env file and restart.")
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{settings.gemini_model}:generateContent"
    )
    data = _post(
        url,
        {"x-goog-api-key": settings.gemini_api_key},
        {
            "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        },
    )
    try:
        parts = data["candidates"][0]["content"]["parts"]
        return "".join(part["text"] for part in parts)
    except (KeyError, IndexError, TypeError) as exc:
        raise LLMError("Gemini returned an unexpected response.") from exc


def _post(url: str, headers: dict[str, str], body: dict) -> dict:
    request = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json", **headers},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise LLMError(
            f"The provider rejected the request (HTTP {exc.code}). Check the API key and model name."
        ) from exc
    except (OSError, TimeoutError) as exc:
        raise LLMError("Could not reach the provider. Check your internet connection.") from exc
    except ValueError as exc:
        raise LLMError("The provider sent an unreadable response.") from exc
