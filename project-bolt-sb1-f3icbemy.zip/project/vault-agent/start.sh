#!/usr/bin/env bash
# Starts Vault Agent using the environment created by setup.sh.
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -x .venv/bin/python ]; then
  echo "Run ./setup.sh first."
  exit 1
fi

exec .venv/bin/python run.py
